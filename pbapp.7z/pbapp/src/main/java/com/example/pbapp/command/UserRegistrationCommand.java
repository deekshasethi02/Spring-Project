package com.example.pbapp.command;

import com.example.pbapp.domain.User;

public class UserRegistrationCommand {

    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    
    
    
}